// Optional: paste your Apps Script Web App URL here BEFORE building the APK.
// If you do, the app only asks for the PIN. If you leave it empty, the app asks for both.
window.HISAAB_CONFIG = {
  scriptUrl: ""
};
