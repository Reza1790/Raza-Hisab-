# Group Hisaab: Android app

Data lives in your own Google Sheet (that is also your backup). The app reads and writes it through a small Apps Script.

## 1. Backend (10 minutes)
1. Make a new Google Sheet. Open Extensions > Apps Script.
2. Paste everything from `apps-script/Code.gs`.
3. Change `EDITOR_PIN` (yours) and `VIEW_PIN` (for your boss). Use 6 or more characters.
4. Choose `setup` in the function list, press Run, allow access.
5. Deploy > New deployment > Web app. Execute as: Me. Who has access: Anyone. Deploy.
6. Copy the Web app URL (ends with /exec).
7. Choose `installBackupTrigger` in the function list and Run it once. Every morning (around 8 am) the full ledger arrives in your Gmail as a CSV.

Where the data lives: in this Google Sheet, in the Google Drive of the account you used. Lost phone is fine: open the Sheet from any device, or reinstall the app and enter the URL and PIN.

Optional: paste that URL into `app/src/main/assets/config.js` before building, so the app only asks for a PIN.

## 2. Build the APK
1. Make a new GitHub repository and upload everything in this folder (keep the `.github` folder).
2. Open the Actions tab. "Build APK" runs by itself (or press Run workflow).
3. When it finishes, open the run and download `group-hisaab-apk`. Unzip it and install `app-debug.apk` on the phone.

## 3. Use it
- You: open the app, enter the URL (if asked) and the editor PIN.
- Boss: install the same APK, enter the same URL and the view PIN. He sees every update, and cannot change anything.
- The app refreshes every 20 seconds and when you reopen it.

## Changing a PIN
Edit the PIN in Code.gs, then Deploy > Manage deployments > edit > New version > Deploy. The URL stays the same.
