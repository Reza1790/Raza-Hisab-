/**
 * Group Hisaab backend (Google Apps Script).
 * Data lives in THIS Google Sheet (tabs "Entries" and "Settings"), so the sheet is also your backup.
 *
 * SETUP
 * 1. Make a new Google Sheet, open Extensions > Apps Script, paste this file.
 * 2. Change the two PINs below (use 6+ characters).
 * 3. Run setup() once from the editor and allow access.
 * 4. Deploy > New deployment > type "Web app" > Execute as: Me > Who has access: Anyone > Deploy.
 * 5. Copy the Web app URL. Put it in the app.
 *
 * EDITOR_PIN lets you add, edit and delete. VIEW_PIN is for your boss: he can only look.
 */
var EDITOR_PIN = 'j3eybem2';
var VIEW_PIN   = 'tsdmu2pz';

var COLS = ['id','date','type','person','firm','category','note','currency','amount','usd','rate','createdAt'];
var TYPES = ['purchase','expense','payout','received'];

/**
 * Press the Run button once. It prepares the Sheet and turns on the daily email backup.
 */
function start() {
  setup();
  installBackupTrigger();
}

function setup() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var e = ss.getSheetByName('Entries') || ss.insertSheet('Entries');
  e.getRange(1, 1, 1, COLS.length).setValues([COLS]).setFontWeight('bold');
  e.getRange('A:H').setNumberFormat('@');
  e.setFrozenRows(1);
  var s = ss.getSheetByName('Settings') || ss.insertSheet('Settings');
  if (!s.getRange('B1').getValue()) s.getRange('A1:B1').setValues([['rate', 285]]);
  var d = ss.getSheetByName('Sheet1');
  if (d && ss.getSheets().length > 1 && d.getLastRow() === 0) ss.deleteSheet(d);
}

/**
 * Daily backup to your Gmail. Run installBackupTrigger() once from the editor.
 * Every morning you get an email with a CSV of all entries, sent to the account that owns this Sheet.
 */
function installBackupTrigger() {
  ScriptApp.getProjectTriggers().forEach(function (t) {
    if (t.getHandlerFunction() === 'emailBackup') ScriptApp.deleteTrigger(t);
  });
  ScriptApp.newTrigger('emailBackup').timeBased().everyDays(1).atHour(8).create();
}

function emailBackup() {
  var rows = list_('editor').entries;
  var q = function (v) { return '"' + String(v == null ? '' : v).replace(/"/g, '""') + '"'; };
  var cols = ['date','type','person','firm','category','note','currency','amount','usd'];
  rows.sort(function (a, b) { return String(a.date).localeCompare(String(b.date)); });
  var csv = '\uFEFF' + cols.join(',') + '\n' + rows.map(function (r) {
    return cols.map(function (c) { return q(r[c]); }).join(',');
  }).join('\n');
  var day = Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyy-MM-dd');
  MailApp.sendEmail({
    to: Session.getEffectiveUser().getEmail(),
    subject: 'Group Hisaab backup ' + day,
    body: rows.length + ' entries attached. Keep this email as a backup.',
    attachments: [Utilities.newBlob(csv, 'text/csv', 'group-hisaab-' + day + '.csv')]
  });
}

function doGet(e) {
  var p = (e && e.parameter) || {};
  var out;
  try {
    var role = p.pin === EDITOR_PIN ? 'editor' : (p.pin === VIEW_PIN ? 'viewer' : null);
    if (!role) {
      out = { error: 'bad_pin' };
    } else if (p.action === 'list') {
      out = list_(role);
    } else if (role !== 'editor') {
      out = { error: 'view_only' };
    } else {
      var lock = LockService.getScriptLock();
      lock.waitLock(15000);
      try {
        if (p.action === 'add') add_(JSON.parse(p.data));
        else if (p.action === 'update') update_(p.id, JSON.parse(p.data));
        else if (p.action === 'delete') delete_(p.id);
        else if (p.action === 'rate') rate_(p.value);
        else throw 'bad_action';
        SpreadsheetApp.flush();
      } finally { lock.releaseLock(); }
      out = list_(role);
    }
  } catch (err) {
    out = { error: 'server', message: String(err) };
  }
  return ContentService.createTextOutput(JSON.stringify(out)).setMimeType(ContentService.MimeType.JSON);
}

function sheet_(name) {
  var sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(name);
  if (!sh) { setup(); sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(name); }
  return sh;
}

function list_(role) {
  var sh = sheet_('Entries');
  var tz = SpreadsheetApp.getActiveSpreadsheet().getSpreadsheetTimeZone();
  var n = sh.getLastRow() - 1;
  var entries = [];
  if (n > 0) {
    var vals = sh.getRange(2, 1, n, COLS.length).getValues();
    vals.forEach(function (r) {
      if (!r[0]) return;
      var o = {};
      COLS.forEach(function (c, i) { o[c] = r[i]; });
      if (o.date instanceof Date) o.date = Utilities.formatDate(o.date, tz, 'yyyy-MM-dd');
      o.amount = Number(o.amount) || 0;
      o.usd = Number(o.usd) || 0;
      o.rate = Number(o.rate) || 0;
      o.createdAt = Number(o.createdAt) || 0;
      entries.push(o);
    });
  }
  var rate = Number(sheet_('Settings').getRange('B1').getValue()) || 285;
  return { ok: true, role: role, rate: rate, entries: entries };
}

function clean_(d) {
  if (TYPES.indexOf(d.type) < 0) throw 'bad_type';
  var amount = Number(d.amount);
  if (!(amount > 0)) throw 'bad_amount';
  var t = function (v, n) { return String(v == null ? '' : v).slice(0, n); };
  return {
    date: t(d.date, 10), type: d.type, person: t(d.person, 80), firm: t(d.firm, 80),
    category: t(d.category, 40), note: t(d.note, 200),
    currency: d.currency === 'PKR' ? 'PKR' : 'USD',
    amount: amount, usd: Number(d.usd) || 0, rate: Number(d.rate) || '',
    createdAt: Number(d.createdAt) || Date.now()
  };
}

function add_(d) {
  var o = clean_(d);
  o.id = Utilities.getUuid();
  var sh = sheet_('Entries');
  sh.appendRow(COLS.map(function (c) { return o[c]; }));
}

function findRow_(id) {
  var sh = sheet_('Entries');
  var n = sh.getLastRow() - 1;
  if (n < 1) throw 'not_found';
  var ids = sh.getRange(2, 1, n, 1).getValues();
  for (var i = 0; i < ids.length; i++) if (ids[i][0] === id) return i + 2;
  throw 'not_found';
}

function update_(id, d) {
  var o = clean_(d);
  o.id = id;
  var row = findRow_(id);
  sheet_('Entries').getRange(row, 1, 1, COLS.length).setValues([COLS.map(function (c) { return o[c]; })]);
}

function delete_(id) {
  sheet_('Entries').deleteRow(findRow_(id));
}

function rate_(v) {
  var r = Number(v);
  if (!(r > 0)) throw 'bad_rate';
  sheet_('Settings').getRange('A1:B1').setValues([['rate', r]]);
}

// ===== END OF CODE: iske neeche kuch nahi hona chahiye =====
