// Web app URL of the Google Apps Script backend. The app only asks for the PIN.
window.HISAAB_CONFIG = {
  scriptUrl: "https://script.google.com/macros/s/AKfycbwXVGnpsn004nSnFxyidWdqd-h1MqrKV4_iY7m7CoE3Hgc6t7e4mPJTdubf9rt3vu_y/exec"
};
